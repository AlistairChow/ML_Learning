# -*- coding: utf8 -*-

class Movie():
    def __init__(self, movie_title, movie_stroyline, poster_image_url, trailer_url):
        self.title = movie_title
        self.storyline = movie_stroyline
        self.poster_image_url = poster_image_url
        self.trailer_url = trailer_url
